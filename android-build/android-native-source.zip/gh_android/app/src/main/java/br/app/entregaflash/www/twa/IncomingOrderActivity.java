package br.app.entregaflash.www.twa;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Locale;

/**
 * Chamada nativa do motorista.
 *
 * A Activity continua podendo abrir sobre a tela bloqueada, mas visualmente funciona
 * como um popup/modal centralizado, compacto e com o mesmo estilo do Entrega Flash.
 */
public class IncomingOrderActivity extends Activity {
    public static final String EXTRA_ORDER_JSON = "order_json";

    private static final int COR_FUNDO = Color.rgb(8, 10, 13);
    private static final int COR_CARD = Color.rgb(18, 21, 26);
    private static final int COR_CARD_2 = Color.rgb(24, 28, 34);
    private static final int COR_LINHA = Color.rgb(58, 64, 74);
    private static final int COR_TEXTO_2 = Color.rgb(190, 196, 207);
    private static final int COR_LARANJA = Color.rgb(255, 145, 24);
    private static final int COR_AMARELO = Color.rgb(255, 193, 7);
    private static final int COR_VERDE = Color.rgb(27, 201, 76);
    private static final int COR_VERMELHO = Color.rgb(239, 59, 65);

    private String orderId = "";
    private String phone = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        configurarJanela();
        render(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render(intent);
    }

    private void configurarJanela() {
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(7, 8, 10));
        w.setNavigationBarColor(Color.rgb(7, 8, 10));
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
    }

    private void render(Intent intent) {
        String raw = intent != null ? intent.getStringExtra(EXTRA_ORDER_JSON) : null;
        phone = intent != null ? digits(intent.getStringExtra(LocationForegroundService.EXTRA_PHONE)) : "";

        try {
            JSONObject o = new JSONObject(raw == null ? "{}" : raw);
            orderId = o.optString("id", "");
            String origem = o.optString("origem", "Origem não informada");
            String destino = o.optString("destino", "Destino não informado");
            double preco = o.optDouble("preco", 0);
            double distancia = o.optDouble("distancia", 0);
            double ate = o.optDouble("distancia_ate_motorista", -1);

            FrameLayout fundo = new FrameLayout(this);
            fundo.setBackgroundColor(Color.argb(238, 5, 7, 10));
            fundo.setPadding(dp(14), dp(18), dp(14), dp(18));

            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(false);
            scroll.setClipToPadding(false);
            scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(18), dp(18), dp(18), dp(16));
            card.setBackground(roundRect(COR_CARD, dp(24), COR_LINHA, dp(1)));
            if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(18));
            scroll.addView(card, new ScrollView.LayoutParams(-1, -2));

            FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            scrollLp.leftMargin = dp(4);
            scrollLp.rightMargin = dp(4);
            fundo.addView(scroll, scrollLp);

            // Cabeçalho compacto com logo e identificação da chamada.
            LinearLayout topo = new LinearLayout(this);
            topo.setOrientation(LinearLayout.HORIZONTAL);
            topo.setGravity(Gravity.CENTER_VERTICAL);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.entrega_flash_icon);
            logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable logoBg = roundRect(Color.rgb(9, 10, 13), dp(15), COR_LARANJA, dp(1));
            logo.setBackground(logoBg);
            logo.setPadding(dp(2), dp(2), dp(2), dp(2));
            topo.addView(logo, lp(dp(58), dp(58), 0, 0, 0, 0));

            LinearLayout cabecalho = new LinearLayout(this);
            cabecalho.setOrientation(LinearLayout.VERTICAL);
            cabecalho.setPadding(dp(12), 0, 0, 0);

            TextView marca = text("ENTREGA FLASH", 14, true);
            marca.setTextColor(COR_LARANJA);
            marca.setLetterSpacing(0.08f);
            cabecalho.addView(marca);

            TextView call = text("Novo pedido disponível!", 21, true);
            call.setTextColor(Color.WHITE);
            cabecalho.addView(call, lp(-1, -2, 0, 0, dp(2), 0));

            TextView callSub = text("Confira os dados e escolha rapidamente.", 12, false);
            callSub.setTextColor(COR_TEXTO_2);
            cabecalho.addView(callSub, lp(-1, -2, 0, 0, dp(3), 0));

            topo.addView(cabecalho, lp(0, -2, 1, 0, 0, 0));
            card.addView(topo, lp(-1, -2, 0, 0, 0, dp(14)));

            // Valor em destaque, sem ocupar a tela inteira.
            LinearLayout valorBox = new LinearLayout(this);
            valorBox.setOrientation(LinearLayout.VERTICAL);
            valorBox.setGravity(Gravity.CENTER);
            valorBox.setPadding(dp(12), dp(10), dp(12), dp(10));
            valorBox.setBackground(roundRect(Color.rgb(12, 34, 20), dp(16), Color.rgb(31, 119, 63), dp(1)));

            TextView valorLabel = text("VALOR DA CORRIDA", 11, true);
            valorLabel.setGravity(Gravity.CENTER);
            valorLabel.setTextColor(Color.rgb(154, 224, 176));
            valorLabel.setLetterSpacing(0.10f);
            valorBox.addView(valorLabel);

            TextView value = text(String.format(Locale.forLanguageTag("pt-BR"), "R$ %.2f", preco), 31, true);
            value.setTextColor(Color.rgb(101, 235, 128));
            value.setGravity(Gravity.CENTER);
            valorBox.addView(value, lp(-1, -2, 0, 0, dp(2), 0));
            card.addView(valorBox, lp(-1, -2, 0, 0, 0, dp(12)));

            // Coleta.
            card.addView(enderecoCard("📦", "COLETA", origem, COR_LARANJA), lp(-1, -2, 0, 0, 0, dp(9)));

            // Entrega.
            card.addView(enderecoCard("📍", "ENTREGA", destino, COR_VERDE), lp(-1, -2, 0, 0, 0, dp(10)));

            // Distâncias em chips compactos.
            LinearLayout chips = new LinearLayout(this);
            chips.setOrientation(LinearLayout.HORIZONTAL);
            chips.setGravity(Gravity.CENTER);

            if (distancia > 0) {
                chips.addView(chip(String.format(Locale.forLanguageTag("pt-BR"), "🛣  %.1f km de corrida", distancia), COR_AMARELO), lp(0, dp(42), 1, 0, 0, ate >= 0 ? dp(5) : 0));
            }
            if (ate >= 0) {
                chips.addView(chip(String.format(Locale.forLanguageTag("pt-BR"), "📡  %.1f km até coleta", ate), Color.rgb(94, 181, 255)), lp(0, dp(42), 1, distancia > 0 ? dp(5) : 0, 0, 0));
            }
            if (chips.getChildCount() > 0) card.addView(chips, lp(-1, -2, 0, 0, 0, dp(13)));

            TextView aviso = text("⚡ Responda rápido. Se recusar, a chamada segue para outro motorista.", 12, false);
            aviso.setTextColor(COR_TEXTO_2);
            aviso.setGravity(Gravity.CENTER);
            aviso.setPadding(dp(8), 0, dp(8), 0);
            card.addView(aviso, lp(-1, -2, 0, 0, 0, dp(14)));

            // Ações: sempre visíveis, grandes e com cores claras.
            LinearLayout acoes = new LinearLayout(this);
            acoes.setOrientation(LinearLayout.HORIZONTAL);
            acoes.setGravity(Gravity.CENTER);

            Button accept = actionButton("✓  ACEITAR", COR_VERDE);
            accept.setOnClickListener(v -> acceptOrder());
            acoes.addView(accept, lp(0, dp(58), 1, 0, 0, dp(6)));

            Button reject = actionButton("✕  RECUSAR", COR_VERMELHO);
            reject.setOnClickListener(v -> rejectOrder());
            acoes.addView(reject, lp(0, dp(58), 1, dp(6), 0, 0));

            card.addView(acoes);

            TextView rodape = text("ENTREGA FLASH  •  MAIS ENTREGAS, MAIS CONQUISTAS", 10, true);
            rodape.setTextColor(Color.rgb(126, 132, 143));
            rodape.setGravity(Gravity.CENTER);
            rodape.setLetterSpacing(0.08f);
            card.addView(rodape, lp(-1, -2, 0, 0, dp(13), 0));

            setContentView(fundo);
        } catch (Exception e) {
            finish();
        }
    }

    private View enderecoCard(String icone, String titulo, String endereco, int accent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        row.setBackground(roundRect(COR_CARD_2, dp(15), COR_LINHA, dp(1)));

        TextView icon = text(icone, 24, false);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, lp(dp(40), dp(40), 0, 0, 0, 0));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), 0, 0, 0);

        TextView t = text(titulo, 12, true);
        t.setTextColor(accent);
        t.setLetterSpacing(0.08f);
        col.addView(t);

        TextView e = text(endereco, 16, true);
        e.setTextColor(Color.WHITE);
        e.setLineSpacing(0, 1.08f);
        col.addView(e, lp(-1, -2, 0, 0, dp(3), 0));

        row.addView(col, lp(0, -2, 1, 0, 0, 0));
        return row;
    }

    private TextView chip(String s, int cor) {
        TextView t = text(s, 12, true);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(cor);
        t.setSingleLine(true);
        t.setBackground(roundRect(Color.rgb(29, 33, 39), dp(12), Color.rgb(54, 60, 70), dp(1)));
        t.setPadding(dp(8), 0, dp(8), 0);
        return t;
    }

    private void acceptOrder() {
        if (orderId.isEmpty() || phone.isEmpty()) return;
        SupabaseApi.acceptOrderAsync(orderId, phone, (ok, message) -> runOnUiThread(() -> {
            if (ok) {
                LocationForegroundService.stopIncomingAlert(this, orderId);
                Toast.makeText(this, "Entrega aceita!", Toast.LENGTH_LONG).show();
                Intent open = new Intent(this, LauncherActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(open);
                finish();
            } else {
                Toast.makeText(this,
                        message == null ? "Essa entrega não está mais disponível." : message,
                        Toast.LENGTH_LONG).show();
                LocationForegroundService.stopIncomingAlert(this, orderId);
                finish();
            }
        }));
    }

    private void rejectOrder() {
        LocationForegroundService.ignoreIncomingOrder(this, orderId);
        finish();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button actionButton(String s, int bg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(roundRect(bg, dp(16), Color.TRANSPARENT, 0));
        if (Build.VERSION.SDK_INT >= 21) b.setElevation(dp(3));
        return b;
    }

    private GradientDrawable roundRect(int fill, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(l, t, 0, b);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static String digits(String v) {
        return v == null ? "" : v.replaceAll("\\D", "");
    }
}
