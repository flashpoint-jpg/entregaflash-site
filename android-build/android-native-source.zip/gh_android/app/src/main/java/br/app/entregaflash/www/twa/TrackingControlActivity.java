package br.app.entregaflash.www.twa;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

/**
 * Activity transparente aberta por entregaflash://tracking/start|stop.
 * Mantida viva durante os prompts de permissão para receber corretamente o retorno
 * do Android antes de iniciar o Foreground Service.
 */
public class TrackingControlActivity extends Activity {
    private static final String TAG = "EntregaFlashTrackCtl";
    private static final int REQ_LOCATION = 4101;
    private static final int REQ_NOTIFICATIONS = 4102;
    private String pendingPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        Uri data = intent != null ? intent.getData() : null;
        String operation = data != null ? data.getLastPathSegment() : null;
        String phone = data != null ? data.getQueryParameter("phone") : null;
        phone = digits(phone);

        if ("stop".equalsIgnoreCase(operation)) {
            stopTracking(phone);
            finish();
            return;
        }

        if (!"start".equalsIgnoreCase(operation) || phone.isEmpty()) {
            finish();
            return;
        }

        pendingPhone = phone;
        if (!hasLocationPermission()) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_LOCATION);
            return;
        }
        continueAfterLocationPermission();
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void continueAfterLocationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        startAndFinish();
    }

    private void startAndFinish() {
        if (pendingPhone == null || pendingPhone.isEmpty()) {
            finish();
            return;
        }
        startTracking(pendingPhone);
        finish();
    }

    private void startTracking(String phone) {
        Intent svc = new Intent(this, LocationForegroundService.class)
                .setAction(LocationForegroundService.ACTION_START)
                .putExtra(LocationForegroundService.EXTRA_PHONE, phone);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
            else startService(svc);
            Toast.makeText(this,
                    "Entrega Flash online: GPS em segundo plano ativado.",
                    Toast.LENGTH_SHORT).show();
        } catch (Throwable error) {
            Log.e(TAG, "Falha ao iniciar GPS em segundo plano", error);
            SupabaseApi.setDriverOfflineAsync(phone);
            Toast.makeText(this,
                    "Não foi possível ativar o GPS em segundo plano. Abra o app e tente novamente.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void stopTracking(String phone) {
        Intent svc = new Intent(this, LocationForegroundService.class)
                .setAction(LocationForegroundService.ACTION_STOP)
                .putExtra(LocationForegroundService.EXTRA_PHONE, phone);
        try {
            startService(svc);
            Toast.makeText(this,
                    "Entrega Flash offline: GPS em segundo plano desligado.",
                    Toast.LENGTH_SHORT).show();
        } catch (Throwable error) {
            Log.e(TAG, "Falha ao encerrar serviço de GPS", error);
            SupabaseApi.setDriverOfflineAsync(phone);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission() && pendingPhone != null && !pendingPhone.isEmpty()) {
                continueAfterLocationPermission();
            } else {
                Toast.makeText(this,
                        "Permita a localização para ficar online e receber pedidos.",
                        Toast.LENGTH_LONG).show();
                if (pendingPhone != null) SupabaseApi.setDriverOfflineAsync(pendingPhone);
                finish();
            }
        } else if (requestCode == REQ_NOTIFICATIONS) {
            // Mesmo se o usuário negar a notificação, o Android ainda permite iniciar o
            // Foreground Service; a notificação ficará disponível conforme as regras do sistema.
            startAndFinish();
        }
    }

    private static String digits(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }
}
