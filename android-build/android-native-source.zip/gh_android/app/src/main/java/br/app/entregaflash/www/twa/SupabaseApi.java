package br.app.entregaflash.www.twa;

import android.util.Log;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class SupabaseApi {
    interface JsonCallback { void onResult(JSONObject value); }
    interface ResultCallback { void onResult(boolean ok, String message); }
    private static final String TAG="EntregaFlashApi";
    private static final String BASE="https://urtpjcndtcleeorpnpct.supabase.co/rest/v1/rpc/";
    private static final String ANON_KEY="sb_publishable_bhe5zL6CgvGrXBXeckK-Fg_zupiWu7A";
    private static final ExecutorService EXECUTOR=Executors.newSingleThreadExecutor();
    private SupabaseApi(){}

    static void sendLocationAsync(String phone,double lat,double lng){ sendLocationAsync(phone,lat,lng,null); }
    static void sendLocationAsync(String phone,double lat,double lng,ResultCallback cb){ EXECUTOR.execute(()->{ boolean ok=false; String msg=null; try{ JSONObject b=new JSONObject(); b.put("p_telefone",phone); b.put("p_lat",lat); b.put("p_lng",lng); String r=postRpc("entrega_motorista_background_ping",b); ok="true".equalsIgnoreCase(r==null?"":r.trim()); if(!ok) msg="ping_rejeitado"; }catch(Exception e){msg=e.getMessage();Log.w(TAG,"Falha GPS",e);} if(cb!=null)cb.onResult(ok,msg); }); }
    static void setDriverOfflineAsync(String phone){ if(phone==null||phone.isEmpty())return; EXECUTOR.execute(()->{ try{JSONObject b=new JSONObject();b.put("p_telefone",phone);b.put("p_disponivel",false);b.put("p_lat",JSONObject.NULL);b.put("p_lng",JSONObject.NULL);postRpc("entrega_motorista_definir_disponivel_com_posicao",b);}catch(Exception e){Log.w(TAG,"Falha offline",e);} }); }

    static void getNextOrderAsync(String phone, String ignoredJson, JsonCallback cb){ EXECUTOR.execute(()->{ JSONObject result=null; try{JSONObject b=new JSONObject();b.put("p_telefone",phone);b.put("p_ignorar_ids",new org.json.JSONArray(ignoredJson==null?"[]":ignoredJson));String r=postRpc("entrega_motorista_background_proximo_pedido",b);if(r!=null&&!r.trim().equals("null")&&!r.trim().isEmpty())result=new JSONObject(r);}catch(Exception e){Log.w(TAG,"Falha ao procurar entrega",e);} if(cb!=null)cb.onResult(result); }); }
    static void isOrderAvailableAsync(String id,String phone,ResultCallback cb){ EXECUTOR.execute(()->{boolean ok=false;try{JSONObject b=new JSONObject();b.put("p_id",id);b.put("p_telefone",phone);ok="true".equalsIgnoreCase(postRpc("entrega_motorista_background_pedido_disponivel",b).trim());}catch(Exception ignored){} if(cb!=null)cb.onResult(ok,null);}); }
    static void acceptOrderAsync(String id,String phone,ResultCallback cb){ EXECUTOR.execute(()->{boolean ok=false;String msg=null;try{JSONObject b=new JSONObject();b.put("p_id",id);b.put("p_telefone",phone);JSONObject r=new JSONObject(postRpc("entrega_motorista_background_aceitar_pedido",b));ok=r.optBoolean("ok",false);msg=reason(r.optString("motivo",""));}catch(Exception e){msg="Não foi possível aceitar agora. Tente novamente.";}if(cb!=null)cb.onResult(ok,msg);}); }
    private static String reason(String r){switch(r){case"pedido_indisponivel":return"Outro motorista já aceitou essa entrega.";case"motorista_offline":return"Você está offline no Entrega Flash.";case"pedido_reservado":return"Entrega reservada ao motorista favorito por alguns segundos.";case"aguarde_prioridade":return"Motoristas Pro têm prioridade por alguns segundos.";case"limite_simultaneo":return"Você atingiu o limite de entregas simultâneas.";default:return"Essa entrega não está mais disponível.";}}

    private static String postRpc(String function,JSONObject body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(BASE+function).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("apikey",ANON_KEY);c.setRequestProperty("Authorization","Bearer "+ANON_KEY);byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}int code=c.getResponseCode();InputStream st=code>=200&&code<300?c.getInputStream():c.getErrorStream();String response=readAll(st);c.disconnect();if(code<200||code>=300)throw new IllegalStateException("HTTP "+code+" "+response);return response;}
    private static String readAll(InputStream in){if(in==null)return"";try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String l;while((l=br.readLine())!=null)s.append(l);return s.toString();}catch(Exception e){return"";}}
}
