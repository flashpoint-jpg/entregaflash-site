package br.app.entregaflash.www.twa;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.location.*;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.text.format.DateFormat;
import android.util.Log;
import org.json.JSONObject;
import java.util.*;

public class LocationForegroundService extends Service implements LocationListener {
    public static final String ACTION_START="br.app.entregaflash.START_TRACKING", ACTION_STOP="br.app.entregaflash.STOP_TRACKING", EXTRA_PHONE="phone";
    public static final String ACTION_IGNORE="br.app.entregaflash.IGNORE_ORDER", ACTION_CLEAR="br.app.entregaflash.CLEAR_CALL", EXTRA_ORDER_ID="order_id";
    private static final String TAG="EntregaFlashGPS", TRACK_CHANNEL="entrega_flash_tracking", ORDER_CHANNEL="entrega_flash_chamadas_v6";
    private static final int TRACK_ID=4401, ORDER_ID=4410; private static final long POLL_MS=3000L;
    private static final String PREFS="entrega_flash_native", PREF_ENABLED="tracking_enabled", PREF_PHONE="tracking_phone", PREF_IGNORED="ignored_orders";
    private LocationManager lm; private String phone="", activeOrder=""; private long lastSend=0; private Handler handler; private TextToSpeech tts; private MediaPlayer alertPlayer; private volatile boolean pollInFlight=false;
    private Location lastLocation; private long lastFixReceivedAt=0L; private PowerManager.WakeLock wakeLock;
    private static final long PRESENCE_HEARTBEAT_MS=45000L, LAST_LOCATION_MAX_AGE_MS=180000L;
    private final Runnable poll=new Runnable(){public void run(){pollOrder();handler.postDelayed(this,POLL_MS);}};
    private final Runnable repeatAlert=new Runnable(){public void run(){if(!activeOrder.isEmpty()){speakAlert();handler.postDelayed(this,4000L);}}};
    private final Runnable presenceHeartbeat=new Runnable(){public void run(){try{heartbeatPresence();}finally{handler.postDelayed(this,PRESENCE_HEARTBEAT_MS);}}};

    @Override public void onCreate(){super.onCreate();createChannels();lm=(LocationManager)getSystemService(LOCATION_SERVICE);handler=new Handler(Looper.getMainLooper());
        try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"EntregaFlash:MotoristaOnline");wakeLock.setReferenceCounted(false);}}catch(Throwable e){Log.w(TAG,"Falha WakeLock",e);} 
        tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS){tts.setLanguage(new Locale("pt","BR"));tts.setSpeechRate(1.08f);tts.setPitch(1.08f);}});try{AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();alertPlayer=MediaPlayer.create(this,R.raw.entrega_flash_animado_mais_alto,attrs,0);if(alertPlayer!=null)alertPlayer.setVolume(1.0f,1.0f);}catch(Throwable e){Log.w(TAG,"Falha ao preparar audio personalizado",e);alertPlayer=null;}}
    @Override public int onStartCommand(Intent i,int flags,int id){SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);String action=i!=null?i.getAction():null;String incoming=i!=null?digits(i.getStringExtra(EXTRA_PHONE)):"";if(!incoming.isEmpty())phone=incoming;if(phone.isEmpty())phone=digits(p.getString(PREF_PHONE,""));
        if(ACTION_IGNORE.equals(action)){addIgnoredOrder(this,i.getStringExtra(EXTRA_ORDER_ID));cancelCall();handler.removeCallbacks(poll);handler.postDelayed(poll,500);return START_STICKY;}
        if(ACTION_CLEAR.equals(action)){cancelCall();handler.removeCallbacks(poll);handler.postDelayed(poll,500);return START_STICKY;}
        if(ACTION_STOP.equals(action)){p.edit().putBoolean(PREF_ENABLED,false).apply();stopUpdates();handler.removeCallbacks(poll);handler.removeCallbacks(presenceHeartbeat);cancelCall();releaseWakeLock();SupabaseApi.setDriverOfflineAsync(phone);stopForeground(true);stopSelf();return START_NOT_STICKY;}
        boolean run=ACTION_START.equals(action)||p.getBoolean(PREF_ENABLED,false);if(!run||phone.isEmpty()){stopSelf();return START_NOT_STICKY;}p.edit().putBoolean(PREF_ENABLED,true).putString(PREF_PHONE,phone).apply();
        try{startForegroundNative("GPS ativo · procurando posição");acquireWakeLock();startUpdates();handler.removeCallbacks(poll);handler.post(poll);handler.removeCallbacks(presenceHeartbeat);handler.postDelayed(presenceHeartbeat,15000L);return START_STICKY;}catch(Throwable e){Log.e(TAG,"Falha serviço",e);p.edit().putBoolean(PREF_ENABLED,false).apply();releaseWakeLock();stopSelf();return START_NOT_STICKY;}}

    private void pollOrder(){if(phone.isEmpty()||!activeOrder.isEmpty()||pollInFlight)return;pollInFlight=true;String ignored=getIgnoredJson();SupabaseApi.getNextOrderAsync(phone,ignored,o->{pollInFlight=false;if(o==null||!activeOrder.isEmpty())return;String id=o.optString("id","");if(id.isEmpty())return;activeOrder=id;showIncoming(o);});}
    private void showIncoming(JSONObject o){String id=o.optString("id","");Intent popup=new Intent(this,IncomingOrderActivity.class).putExtra(IncomingOrderActivity.EXTRA_ORDER_JSON,o.toString()).putExtra(EXTRA_PHONE,phone).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int requestCode=1000+Math.abs(id.hashCode()%50000);PendingIntent full=PendingIntent.getActivity(this,requestCode,popup,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent reject=new Intent(this,LocationForegroundService.class).setAction(ACTION_IGNORE).putExtra(EXTRA_PHONE,phone).putExtra(EXTRA_ORDER_ID,id);PendingIntent rejectPi=PendingIntent.getService(this,101,reject,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String body=String.format(Locale.forLanguageTag("pt-BR"),"R$ %.2f · %s → %s",o.optDouble("preco",0),o.optString("origem","Coleta"),o.optString("destino","Entrega"));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ORDER_CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("⚡ ENTREGA FLASH · NOVA ENTREGA").setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PUBLIC).setAutoCancel(false).setOngoing(true).setOnlyAlertOnce(true).setFullScreenIntent(full,true).setContentIntent(full).setVibrate(new long[]{0,450,180,450,180,700}).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_view,"ABRIR / ACEITAR",full).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"RECUSAR",rejectPi).build());
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.notify(ORDER_ID,b.build());
        // Toca IMEDIATAMENTE. Antes o áudio só começava na repetição alguns segundos depois.
        speakAlert();
        handler.removeCallbacks(repeatAlert); handler.postDelayed(repeatAlert,4000L);
    }
    private void speakAlert(){handler.postDelayed(()->{try{if(alertPlayer!=null){if(alertPlayer.isPlaying())alertPlayer.pause();alertPlayer.seekTo(0);alertPlayer.start();return;}}catch(Exception e){Log.w(TAG,"Falha audio personalizado",e);}try{if(tts!=null)tts.speak("Entrega Flash!",TextToSpeech.QUEUE_FLUSH,null,"ef_call");}catch(Exception ignored){}},250);}
    private void cancelCall(){handler.removeCallbacks(repeatAlert);activeOrder="";NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.cancel(ORDER_ID);try{if(alertPlayer!=null){if(alertPlayer.isPlaying())alertPlayer.pause();alertPlayer.seekTo(0);}}catch(Exception ignored){}try{if(tts!=null)tts.stop();}catch(Exception ignored){}}
    public static void stopIncomingAlert(Context c,String id){Intent i=new Intent(c,LocationForegroundService.class).setAction(ACTION_CLEAR).putExtra(EXTRA_ORDER_ID,id);c.startService(i);NotificationManager nm=(NotificationManager)c.getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.cancel(ORDER_ID);}
    public static void ignoreIncomingOrder(Context c,String id){if(id==null||id.isEmpty())return; Intent i=new Intent(c,LocationForegroundService.class).setAction(ACTION_IGNORE).putExtra(EXTRA_ORDER_ID,id); try{c.startService(i);}catch(Exception e){addIgnoredOrder(c,id);} NotificationManager nm=(NotificationManager)c.getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.cancel(ORDER_ID);}
    private static void addIgnoredOrder(Context c,String id){if(id==null||id.isEmpty())return;SharedPreferences p=c.getSharedPreferences(PREFS,MODE_PRIVATE);try{org.json.JSONArray a=new org.json.JSONArray(p.getString(PREF_IGNORED,"[]"));a.put(id);while(a.length()>20){org.json.JSONArray n=new org.json.JSONArray();for(int x=1;x<a.length();x++)n.put(a.get(x));a=n;}p.edit().putString(PREF_IGNORED,a.toString()).apply();}catch(Exception ignored){}}
    private String getIgnoredJson(){return getSharedPreferences(PREFS,MODE_PRIVATE).getString(PREF_IGNORED,"[]");}

    private void startForegroundNative(String text){Notification n=buildTrack(text);if(Build.VERSION.SDK_INT>=29)startForeground(TRACK_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);else startForeground(TRACK_ID,n);}
    private Notification buildTrack(String text){Intent open=new Intent(this,LauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent op=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,LocationForegroundService.class).setAction(ACTION_STOP).putExtra(EXTRA_PHONE,phone);PendingIntent sp=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,TRACK_CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("Entrega Flash · motorista online").setContentText(text).setContentIntent(op).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"Ficar offline",sp).build()).build();}
    private void updateTrack(String text){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.notify(TRACK_ID,buildTrack(text));}
    private boolean hasLocationPermission(){return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private boolean providerAvailable(){try{return (lm!=null&&lm.isProviderEnabled(LocationManager.GPS_PROVIDER))||(lm!=null&&lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER));}catch(Exception e){return false;}}
    private void startUpdates(){
        if(!hasLocationPermission()){updateTrack("Permita Localização para ficar online");stopSelf();return;}
        stopUpdates();
        // IMPORTANTE: distância ZERO. O motorista parado também precisa renovar presença.
        try{if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER))lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000L,0f,this,Looper.getMainLooper());}catch(Exception e){Log.w(TAG,"GPS provider",e);}
        try{if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,15000L,0f,this,Looper.getMainLooper());}catch(Exception e){Log.w(TAG,"NETWORK provider",e);}
        seedLastKnownLocation();
    }
    private void seedLastKnownLocation(){
        if(!hasLocationPermission()||lm==null)return;
        Location best=null;
        try{Location g=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(g!=null)best=g;}catch(Exception ignored){}
        try{Location n=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(n!=null&&(best==null||n.getTime()>best.getTime()))best=n;}catch(Exception ignored){}
        if(best!=null){long now=System.currentTimeMillis(),fix=best.getTime()>0?best.getTime():now;if(now-fix<=LAST_LOCATION_MAX_AGE_MS){lastLocation=best;lastFixReceivedAt=now;sendPresence(best,true);}}
    }
    private void sendPresence(Location l,boolean force){
        if(l==null||phone.isEmpty())return;
        long now=System.currentTimeMillis();
        if(!force&&now-lastSend<8000L)return;
        lastSend=now;
        final double lat=l.getLatitude(),lng=l.getLongitude();
        SupabaseApi.sendLocationAsync(phone,lat,lng,(ok,msg)->handler.post(()->{
            if(ok) updateTrack("Online · GPS atualizado às "+DateFormat.format("HH:mm:ss",new Date()));
            else updateTrack("Sem internet · tentando reconectar automaticamente");
        }));
    }
    private void heartbeatPresence(){
        if(phone.isEmpty()||!hasLocationPermission())return;
        if(!providerAvailable()){updateTrack("Localização desligada · ative o GPS");return;}
        long now=System.currentTimeMillis();
        // Se recebemos posição recentemente, reenvia como HEARTBEAT mesmo sem movimento.
        // Isso impede o banco de considerar o motorista offline só porque ele ficou parado.
        if(lastLocation!=null&&lastFixReceivedAt>0&&now-lastFixReceivedAt<=LAST_LOCATION_MAX_AGE_MS){sendPresence(lastLocation,true);return;}
        startUpdates();
    }
    @Override public void onLocationChanged(Location l){if(l==null)return;long now=System.currentTimeMillis(),fix=l.getTime()>0?l.getTime():now;if(now-fix>180000L)return;lastLocation=l;lastFixReceivedAt=now;sendPresence(l,false);}
    @Override public void onProviderDisabled(String p){updateTrack("Localização sem sinal · reconexão automática ativa");}
    @Override public void onProviderEnabled(String p){updateTrack("GPS ativo · buscando posição");handler.postDelayed(this::startUpdates,500L);}
    @Override public void onStatusChanged(String p,int s,Bundle e){}
    private void acquireWakeLock(){try{if(wakeLock!=null&&!wakeLock.isHeld())wakeLock.acquire();}catch(Throwable e){Log.w(TAG,"WakeLock acquire",e);}}
    private void releaseWakeLock(){try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Throwable ignored){}}
    private void createChannels(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel tr=new NotificationChannel(TRACK_CHANNEL,"Motorista online",NotificationManager.IMPORTANCE_LOW);tr.setSound(null,null);nm.createNotificationChannel(tr);NotificationChannel call=new NotificationChannel(ORDER_CHANNEL,"Chamadas de entrega",NotificationManager.IMPORTANCE_HIGH);call.setDescription("Nova corrida/pedido do Entrega Flash");call.enableVibration(true);call.setVibrationPattern(new long[]{0,450,180,450,180,700});call.enableLights(true);call.setLightColor(Color.YELLOW);Uri sound=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.entrega_flash_animado_mais_alto);call.setSound(sound,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());call.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(call);}}
    private void stopUpdates(){try{if(lm!=null)lm.removeUpdates(this);}catch(Exception ignored){}}
    @Override public void onDestroy(){handler.removeCallbacks(poll);handler.removeCallbacks(presenceHeartbeat);stopUpdates();cancelCall();releaseWakeLock();if(alertPlayer!=null){try{alertPlayer.release();}catch(Exception ignored){}alertPlayer=null;}if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}@Override public IBinder onBind(Intent i){return null;}private static String digits(String v){return v==null?"":v.replaceAll("\\D","");}
}
