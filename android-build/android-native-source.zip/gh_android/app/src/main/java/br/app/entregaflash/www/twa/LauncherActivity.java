package br.app.entregaflash.www.twa;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

/**
 * Tela principal NATIVA e persistente do Entrega Flash.
 *
 * Esta versao deixa de usar a TWA/Chrome como tela principal. A TWA funcionava
 * para navegar, mas ao site abrir entregaflash://tracking/start o Android podia
 * trocar de tarefa, iniciar a Activity transparente do GPS e depois deixar so o
 * Foreground Service visivel. O motorista ficava online, mas "perdia" a tela.
 *
 * Agora o site roda dentro de um WebView pertencente ao proprio APK. O comando
 * entregaflash://tracking/start|stop e interceptado aqui e encaminhado para a
 * TrackingControlActivity sem sair da tela principal. Assim:
 * - o app continua nos Recentes;
 * - tocar no icone/notificacao volta para a mesma tela;
 * - GPS e chamadas continuam no LocationForegroundService;
 * - WhatsApp/Waze/links externos continuam abrindo fora do app.
 */
public class LauncherActivity extends Activity {
    private static final String TAG = "EntregaFlashMain";
    private static final String HOME_URL = "https://entregaflash.app.br/?ef_native=1";
    private static final int REQ_WEB_LOCATION = 5101;
    private static final int REQ_FILE_CHOOSER = 5102;

    private WebView webView;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> pendingFileCallback;
    private Uri pendingCameraUri;
    private boolean sessionRestoreChecked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();

        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            return;
        }

        Uri incoming = getIntent() != null ? getIntent().getData() : null;
        webView.loadUrl(buildVersionedLaunchUri(normalizeIncomingUrl(incoming)).toString());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        // Tocar novamente no icone ou na notificacao nao deve recarregar o site,
        // pois recarregar poderia repetir o comando de "ficar online".
        Uri data = intent != null ? intent.getData() : null;
        if (data != null && isEntregaFlashHttpUrl(data)) {
            webView.loadUrl(buildVersionedLaunchUri(data).toString());
        }
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        try {
            s.setUserAgentString(s.getUserAgentString() + " EntregaFlashNative/2026091403");
        } catch (Throwable ignored) {
        }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            cookies.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request != null ? request.getUrl() : null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    return handleNavigation(url == null ? null : Uri.parse(url));
                } catch (Throwable error) {
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                restoreOnlineDriverSessionOnce();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                    return;
                }
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, REQ_WEB_LOCATION);
            }

            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;
                openFileChooser(fileChooserParams);
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent external = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                external.addCategory(Intent.CATEGORY_BROWSABLE);
                startActivity(external);
            } catch (Throwable error) {
                Toast.makeText(this, "Nao foi possivel abrir o download.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean handleNavigation(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();

        if ("entregaflash".equals(scheme) && "tracking".equalsIgnoreCase(uri.getHost())) {
            // Inicia/encerra o GPS nativo sem tirar a tela principal do app do lugar.
            Intent bridge = new Intent(this, TrackingControlActivity.class);
            bridge.setData(uri);
            startActivity(bridge);
            return true;
        }

        if ("http".equals(scheme) || "https".equals(scheme)) {
            if (isEntregaFlashHttpUrl(uri)) {
                return false; // permanece dentro do app
            }
            openExternal(uri);
            return true;
        }

        if ("intent".equals(scheme)) {
            try {
                Intent parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                if (parsed.resolveActivity(getPackageManager()) != null) {
                    startActivity(parsed);
                    return true;
                }
                String fallback = parsed.getStringExtra("browser_fallback_url");
                if (fallback != null && !fallback.isEmpty()) {
                    openExternal(Uri.parse(fallback));
                    return true;
                }
            } catch (Throwable error) {
                Log.w(TAG, "Falha ao abrir intent externo", error);
            }
            return true;
        }

        // tel:, mailto:, geo:, waze:, whatsapp: e demais apps externos.
        openExternal(uri);
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            Intent external = new Intent(Intent.ACTION_VIEW, uri);
            external.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(external);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Nenhum aplicativo compativel encontrado.", Toast.LENGTH_SHORT).show();
        } catch (Throwable error) {
            Log.w(TAG, "Falha ao abrir link externo: " + uri, error);
        }
    }

    private boolean isEntregaFlashHttpUrl(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if (!"http".equals(scheme) && !"https".equals(scheme)) return false;
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        return "entregaflash.app.br".equals(host) || "www.entregaflash.app.br".equals(host);
    }

    private Uri normalizeIncomingUrl(Uri incoming) {
        return isEntregaFlashHttpUrl(incoming) ? incoming : Uri.parse(HOME_URL);
    }

    /**
     * Preserva qualquer query string existente e substitui apenas a identificacao
     * do APK pelos valores reais desta instalacao.
     */
    private Uri buildVersionedLaunchUri(Uri source) {
        try {
            Uri base = source != null ? source : Uri.parse(HOME_URL);
            Uri.Builder builder = base.buildUpon().clearQuery();
            Set<String> names = base.getQueryParameterNames();
            for (String name : names) {
                if ("ef_native".equals(name)
                        || "ef_app_version".equals(name)
                        || "ef_app_version_name".equals(name)) {
                    continue;
                }
                List<String> values = base.getQueryParameters(name);
                if (values == null || values.isEmpty()) {
                    builder.appendQueryParameter(name, "");
                } else {
                    for (String value : values) {
                        builder.appendQueryParameter(name, value);
                    }
                }
            }
            builder.appendQueryParameter("ef_native", "1");
            builder.appendQueryParameter("ef_app_version", getInstalledVersionCode());
            builder.appendQueryParameter("ef_app_version_name", getInstalledVersionName());
            return builder.build();
        } catch (Throwable error) {
            Log.w(TAG, "Falha ao montar URL versionada", error);
            return Uri.parse(HOME_URL + "&ef_app_version=2026091403");
        }
    }

    private String getInstalledVersionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) return String.valueOf(info.getLongVersionCode());
            return String.valueOf(info.versionCode);
        } catch (Throwable error) {
            return "2026091403";
        }
    }

    private String getInstalledVersionName() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            String name = info.versionName;
            return name == null || name.trim().isEmpty() ? "2026.09.14-tela-fixa-3" : name;
        } catch (Throwable error) {
            return "2026.09.14-tela-fixa-3";
        }
    }


    /**
     * A TWA usa o armazenamento do Chrome e o WebView usa o armazenamento do APK.
     * Para o motorista que estava ONLINE no momento da atualizacao, reaproveitamos
     * o telefone salvo pelo servico nativo e reconstruimos apenas a sessao minima
     * do painel. Isso evita que a troca de TWA -> WebView pareca ter deslogado o
     * motorista. O banco continua sendo a fonte real dos dados quando a pagina
     * restaura a sessao.
     */
    private void restoreOnlineDriverSessionOnce() {
        if (sessionRestoreChecked || webView == null) return;
        sessionRestoreChecked = true;
        try {
            SharedPreferences prefs = getSharedPreferences("entrega_flash_native", MODE_PRIVATE);
            boolean trackingEnabled = prefs.getBoolean("tracking_enabled", false);
            String savedPhone = digits(prefs.getString("tracking_phone", ""));
            if (!trackingEnabled || savedPhone.isEmpty()) return;

            String js = "(function(){try{"
                    + "if(!localStorage.getItem('ef_motorista_telefone')){"
                    + "localStorage.setItem('ef_motorista_telefone','" + savedPhone + "');"
                    + "localStorage.setItem('ef_modo','entregador');"
                    + "localStorage.setItem('ef_motorista_disponivel','true');"
                    + "localStorage.setItem('ef_motorista_quero_online_v1','true');"
                    + "location.reload();return 'restored';}"
                    + "}catch(e){}return 'noop';})()";
            webView.evaluateJavascript(js, null);
        } catch (Throwable error) {
            Log.w(TAG, "Nao foi possivel restaurar sessao do motorista online", error);
        }
    }

    private static String digits(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void openFileChooser(WebChromeClient.FileChooserParams params) {
        Intent contentIntent;
        try {
            contentIntent = params != null ? params.createIntent() : new Intent(Intent.ACTION_GET_CONTENT);
        } catch (Throwable error) {
            contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
        }
        contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
        if (contentIntent.getType() == null) contentIntent.setType("*/*");

        Intent cameraIntent = null;
        try {
            File image = File.createTempFile("entrega_flash_", ".jpg", getCacheDir());
            pendingCameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    image
            );
            cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (cameraIntent.resolveActivity(getPackageManager()) == null) cameraIntent = null;
        } catch (IOException error) {
            Log.w(TAG, "Nao foi possivel preparar camera", error);
            pendingCameraUri = null;
        } catch (Throwable error) {
            Log.w(TAG, "Falha ao preparar camera", error);
            pendingCameraUri = null;
        }

        Intent chooser = Intent.createChooser(contentIntent, "Selecionar foto ou arquivo");
        if (cameraIntent != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        }

        try {
            startActivityForResult(chooser, REQ_FILE_CHOOSER);
        } catch (Throwable error) {
            if (pendingFileCallback != null) {
                pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = null;
            }
            Toast.makeText(this, "Nao foi possivel abrir seus arquivos.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE_CHOOSER || pendingFileCallback == null) return;

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (pendingCameraUri != null) {
                result = new Uri[]{pendingCameraUri};
            }
        }
        pendingFileCallback.onReceiveValue(result);
        pendingFileCallback = null;
        pendingCameraUri = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WEB_LOCATION && pendingGeoCallback != null) {
            boolean allowed = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, allowed, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            // Nao mata a tela principal. Apenas manda para segundo plano.
            // O motorista continua podendo voltar pelos Recentes/icone/notificacao.
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
